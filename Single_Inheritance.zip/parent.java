package Oops.Inheritance;

class a{
	public void first() {
		System.out.println("123");
	}
}
class b extends a{
	public void second() {
		System.out.println("456");

	}
}
public class parent {

}
