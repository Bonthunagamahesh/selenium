package Oops.Inheritance;

public class child extends parent{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		b bb= new b();
		bb.first();
		bb.second();
	}

}
