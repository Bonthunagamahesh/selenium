package Oops.Inheritance;

class first{
	public void Method1() {
		System.out.println("Levitica");
	}
}
class second extends first{
	public void Method2() {
		System.out.println("Technologies Pvt Ltd");
	}
}
public class Single_Inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		second ss=new second();
		ss.Method1();
		ss.Method2();
	}

}
